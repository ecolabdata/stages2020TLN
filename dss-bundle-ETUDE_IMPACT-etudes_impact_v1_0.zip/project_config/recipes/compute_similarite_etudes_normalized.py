# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
similarite_etudes_joined = dataiku.Dataset("similarite_etudes_joined")
similarite_etudes_joined_df = similarite_etudes_joined.get_dataframe()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# # Normalisation du score entre 0 et 100

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
similarite_etudes_normalized_df = similarite_etudes_joined_df
scoreMin = similarite_etudes_normalized_df['score'].min()
scoreMax = similarite_etudes_normalized_df['score'].max()
similarite_etudes_normalized_df['score'] = (similarite_etudes_normalized_df['score']-scoreMin) * 100 / (scoreMax-scoreMin)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Write recipe outputs
similarite_etudes_normalized = dataiku.Dataset("similarite_etudes_normalized")
similarite_etudes_normalized.write_with_schema(similarite_etudes_normalized_df)