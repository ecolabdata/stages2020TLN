# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
import re

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# # Récupération des fichiers du dossier

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
######################
# Read recipe inputs #
######################
etudes_impact = dataiku.Folder("dDkbHkmu")

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# # Convertion des fichiers en dataset avec extraction de l'identifiant du fichier

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
##########################
# Compute recipe outputs #
##########################
paths = etudes_impact.list_paths_in_partition()#extract path of files/directories in the folder
texts = []
ids = []
for path in paths:
    with etudes_impact.get_download_stream(path) as f:
        texts.append(f.read().decode('utf-8'))
        ids.append(re.search(r'([\w-]+)_FEI', path)[1])#get the id of the "MRAE folder" wich is a part of the name file

etudes_dataset_df = pd.DataFrame({'docs':texts, 'id':ids})

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: MARKDOWN
# # Ecriture des données dans un dataset Dataiku

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
########################
# Write recipe outputs #
########################
etudes_dataset = dataiku.Dataset("etudes_dataset")
etudes_dataset.write_with_schema(etudes_dataset_df)