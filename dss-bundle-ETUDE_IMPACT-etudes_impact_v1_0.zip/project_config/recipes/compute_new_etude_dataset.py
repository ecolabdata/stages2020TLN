# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
new_etude = dataiku.Folder("lFwx6fvg")


# Compute recipe outputs
paths = new_etude.list_paths_in_partition()#extract path of file/directory in the folder
data = []
with new_etude.get_download_stream(paths[0]) as f:
    data.append(f.read().decode('utf-8'))


new_etude_dataset_df = pd.DataFrame(data, columns=['docs'])

# Write recipe outputs
new_etude_dataset = dataiku.Dataset("new_etude_dataset")
new_etude_dataset.write_with_schema(new_etude_dataset_df)